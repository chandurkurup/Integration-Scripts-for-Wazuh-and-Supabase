-- ============================================================
-- Wazuh -> Supabase SOC Alerts Schema
-- Run this in Supabase SQL Editor (Project -> SQL Editor -> New query)
-- ============================================================

create table if not exists public.wazuh_alerts (
    id                bigint generated always as identity primary key,
    alert_id          text,                     -- Wazuh's internal alert id (id field in alert json)
    rule_id           integer,                  -- Wazuh rule id
    rule_level        integer not null,         -- Severity level (0-15)
    severity_label    text not null,            -- 'medium' or 'high' (derived)
    rule_description  text,
    rule_groups       text[],                   -- e.g. {authentication,pci_dss}
    rule_mitre_ids    text[],                   -- MITRE ATT&CK technique ids if present
    rule_mitre_tactics text[],

    agent_id          text,
    agent_name        text,
    agent_ip          text,

    manager_name      text,
    location          text,                     -- log source location (e.g. /var/log/auth.log)
    decoder_name      text,

    full_log          text,                     -- raw log line
    srcip             text,                     -- source IP if present (network/auth events)
    dstip             text,
    srcuser           text,
    dstuser           text,

    raw_alert         jsonb not null,            -- entire original Wazuh alert JSON (for forensic/full detail)

    alert_timestamp   timestamptz not null,      -- when Wazuh generated the alert
    received_at       timestamptz not null default now(), -- when our script inserted it

    status            text not null default 'new', -- new | acknowledged | investigating | closed | false_positive
    assigned_to        text,                      -- optional: SOC analyst handling it
    notes             text
);

-- Helpful indexes for SOC dashboard querying
create index if not exists idx_wazuh_alerts_level on public.wazuh_alerts (rule_level);
create index if not exists idx_wazuh_alerts_severity on public.wazuh_alerts (severity_label);
create index if not exists idx_wazuh_alerts_timestamp on public.wazuh_alerts (alert_timestamp desc);
create index if not exists idx_wazuh_alerts_status on public.wazuh_alerts (status);
create index if not exists idx_wazuh_alerts_agent on public.wazuh_alerts (agent_name);
create index if not exists idx_wazuh_alerts_srcip on public.wazuh_alerts (srcip);

-- Enable Row Level Security (recommended for any Supabase table)
alter table public.wazuh_alerts enable row level security;

-- Allow inserts from the service role (used by the Python script) -- service_role bypasses RLS by default,
-- but if you choose to use the anon key instead, uncomment and adjust the policy below:
--
-- create policy "Allow insert for anon (alert ingestion)"
-- on public.wazuh_alerts
-- for insert
-- to anon
-- with check (true);

-- Allow authenticated SOC users to read alerts (adjust to your auth setup)
create policy "Allow authenticated read"
on public.wazuh_alerts
for select
to authenticated
using (true);

-- Optional: allow authenticated users to update status/notes (triage workflow)
create policy "Allow authenticated update"
on public.wazuh_alerts
for update
to authenticated
using (true)
with check (true);
