# Wazuh -> Supabase SOC Alert Pipeline

Forwards every Wazuh alert at **medium (level 7-11)** and **high (level 12-15)**
severity to a Supabase table in near real-time, for SOC dashboarding,
triage, and historical querying.

## How it works

```
Wazuh Manager detects event
        |
        v
Rule fires, level >= 7 (set in ossec.conf)
        |
        v
Wazuh executes custom-supabase.py with alert JSON
        |
        v
Script classifies severity, extracts key fields (IPs, users, MITRE, agent)
        |
        v
POST to Supabase REST API  ->  wazuh_alerts table
```

## Files in this package

| File                              | Purpose                                                          |
|-----------------------------------|-------------------------------------------------------------------|
| `supabase_schema.sql`             | Run once in Supabase SQL Editor to create the `wazuh_alerts` table |
| `custom-supabase.py`              | The integration script Wazuh calls on each alert                  |
| `custom-supabase.conf.example`    | Template for your Supabase URL/key -- copy and fill in            |
| `ossec_conf_snippet.xml`          | XML block to paste into `ossec.conf` to register the integration  |
| `test_integration.py`             | Standalone test harness -- run this first                         |

## Installation steps

### 1. Create the Supabase table
Open your Supabase project -> SQL Editor -> paste the contents of
`supabase_schema.sql` -> Run.

### 2. Get your Supabase credentials
Project Settings -> API:
- **Project URL** (e.g. `https://abcdefgh.supabase.co`)
- **service_role key** (recommended for this server-side script since it
  bypasses Row Level Security; keep it secret, never ship it client-side)

### 3. Configure the script
```bash
cp custom-supabase.conf.example custom-supabase.conf
nano custom-supabase.conf   # fill in SUPABASE_URL and SUPABASE_KEY
```

### 4. Test locally BEFORE touching Wazuh
```bash
pip3 install --upgrade pip   # no extra deps needed, script uses only stdlib
python3 test_integration.py custom-supabase.conf
```
This sends a fake "high" severity test alert end-to-end. Confirm it shows
up in Supabase (Table Editor -> wazuh_alerts -> filter `alert_id` starts
with `test-`), then delete the test rows.

### 5. Install on the Wazuh manager
```bash
sudo cp custom-supabase.py /var/ossec/integrations/
sudo cp custom-supabase.conf /var/ossec/integrations/

# Wazuh requires an executable symlink WITHOUT the .py extension:
sudo ln -s /var/ossec/integrations/custom-supabase.py /var/ossec/integrations/custom-supabase

sudo chmod 750 /var/ossec/integrations/custom-supabase.py
sudo chmod 750 /var/ossec/integrations/custom-supabase
sudo chmod 640 /var/ossec/integrations/custom-supabase.conf
sudo chown root:wazuh /var/ossec/integrations/custom-supabase.py \
                       /var/ossec/integrations/custom-supabase.conf
```

### 6. Register the integration in ossec.conf
```bash
sudo nano /var/ossec/etc/ossec.conf
```
Paste the `<integration>` block from `ossec_conf_snippet.xml` inside the
`<ossec_config>` root element (alongside other top-level blocks, not
nested inside `<global>` or `<rules>`).

### 7. Restart the manager
```bash
sudo systemctl restart wazuh-manager
```

### 8. Generate a real test alert and confirm delivery
Trigger something that produces a medium+ alert (e.g. a few failed SSH
logins against a monitored agent), then check:
```bash
sudo tail -f /var/ossec/logs/integrations.log
```
You should see lines like:
```
... custom-supabase: INFO: Sent alert_id=... rule_id=5712 severity=high -> Supabase (HTTP 201)
```
And the row should appear in your Supabase `wazuh_alerts` table.

## Severity bands (adjust if needed)

| Wazuh level | Label    | Sent to Supabase? |
|-------------|----------|--------------------|
| 0-6         | Low      | No                 |
| 7-11        | Medium   | Yes                |
| 12-15       | High     | Yes                |

To change banding, edit **both**:
- `MEDIUM_LEVEL_MIN` / `HIGH_LEVEL_MIN` constants at the top of `custom-supabase.py`
- the `<level>` value in the `ossec.conf` integration block

Keeping both in sync matters: the `ossec.conf` level is Wazuh's own
pre-filter (so the script isn't invoked at all for low-severity noise),
while the Python constants determine the `severity_label` assigned to
rows that do get through.

## Troubleshooting

- **Nothing arrives in Supabase**: check `/var/ossec/logs/integrations.log`
  first. Most common causes: wrong key (using anon key but no insert
  policy created), wrong table name, or the symlink missing the `.py`
  extension wasn't created.
- **HTTP 401/403 from Supabase**: key is wrong, or you used the anon key
  without adding the commented insert policy in `supabase_schema.sql`.
- **HTTP 404**: `SUPABASE_TABLE` in the conf file doesn't match the table
  name in Supabase, or the URL is missing `/rest/v1/` (handled
  automatically by the script, just confirm `SUPABASE_URL` doesn't already
  include a path).
- **Script never runs at all**: confirm both `custom-supabase` (symlink,
  no extension) and `custom-supabase.py` exist in `/var/ossec/integrations/`
  with execute permissions, and that `ossec.conf` XML is well-formed
  (`sudo /var/ossec/bin/wazuh-control restart` will fail loudly on bad XML).

## Extending this for a full SOC workflow

- Build a small Next.js/React dashboard reading from `wazuh_alerts` via
  Supabase client, filtering by `status = 'new'` for an analyst queue.
- Use Supabase's Realtime feature to push new high-severity alerts to
  the dashboard instantly (subscribe to inserts on the table).
- Add a Supabase Edge Function triggered on insert to fire Slack/email/
  PagerDuty notifications for `severity_label = 'high'` rows.
- Add an analyst `status` update flow (new -> investigating -> closed /
  false_positive) directly against the table for a lightweight ticketing
  loop, already supported by the schema's `status`, `assigned_to`, and
  `notes` columns.
