#!/usr/bin/env python3
"""
custom-supabase.py
------------------
Wazuh custom integration script that forwards Medium and High severity
alerts to a Supabase table over the REST API.

This script is invoked AUTOMATICALLY by the Wazuh manager every time an
alert is generated (if it matches the <integration> block in ossec.conf).
Wazuh calls it like:

    python3 custom-supabase.py <alert_file> <api_key_unused> <hook_url_unused>

Wazuh passes the path to a temp JSON file containing the full alert as the
1st argument. We do NOT rely on argv[2]/argv[3] for credentials -- instead
Supabase URL + API key are read from custom-supabase.conf placed alongside
this script (see SAME_DIR/custom-supabase.conf), so secrets are not exposed
via process listing (ps aux) or Wazuh's integration logs.

Place this file at:   /var/ossec/integrations/custom-supabase.py
Place a symlink at:   /var/ossec/integrations/custom-supabase  (no extension,
                       pointing to this file) -- Wazuh requires both.
Config file at:       /var/ossec/integrations/custom-supabase.conf

See README.md for full installation steps.
"""

import json
import logging
import os
import sys
import time
from logging.handlers import RotatingFileHandler

import urllib.request
import urllib.error

# ----------------------------------------------------------------------
# CONFIGURATION
# ----------------------------------------------------------------------

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))
CONFIG_FILE = os.path.join(SCRIPT_DIR, "custom-supabase.conf")
LOG_FILE = "/var/ossec/logs/integrations.log"

# Severity thresholds (Wazuh rule levels run 0-15).
# Wazuh's own convention: 0-6 low, 7-11 medium, 12-15 high/critical.
# Adjust these two numbers if your org uses different banding.
MEDIUM_LEVEL_MIN = 7
HIGH_LEVEL_MIN = 12

MAX_RETRIES = 3
RETRY_BACKOFF_SECONDS = 2
REQUEST_TIMEOUT = 10

# ----------------------------------------------------------------------
# LOGGING
# ----------------------------------------------------------------------

logger = logging.getLogger("custom-supabase")
logger.setLevel(logging.INFO)
try:
    handler = RotatingFileHandler(LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3)
    handler.setFormatter(logging.Formatter("%(asctime)s custom-supabase: %(levelname)s: %(message)s"))
    logger.addHandler(handler)
except (PermissionError, FileNotFoundError):
    # Fall back to stderr if we can't write to the wazuh log dir (e.g. during local testing)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(asctime)s custom-supabase: %(levelname)s: %(message)s"))
    logger.addHandler(handler)


def load_config():
    """
    Reads SUPABASE_URL and SUPABASE_KEY from custom-supabase.conf.
    Format (simple KEY=VALUE per line, no quotes needed):

        SUPABASE_URL=https://your-project.supabase.co
        SUPABASE_KEY=your-service-role-or-anon-key
        SUPABASE_TABLE=wazuh_alerts
    """
    cfg = {"SUPABASE_TABLE": "wazuh_alerts"}

    if not os.path.isfile(CONFIG_FILE):
        logger.error("Config file not found at %s", CONFIG_FILE)
        return cfg

    with open(CONFIG_FILE, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            cfg[key.strip()] = value.strip()

    return cfg


# ----------------------------------------------------------------------
# ALERT PARSING / NORMALIZATION
# ----------------------------------------------------------------------

def classify_severity(level):
    """Map a numeric Wazuh rule level to a severity label. Returns None if below threshold (ignored)."""
    if level >= HIGH_LEVEL_MIN:
        return "high"
    if level >= MEDIUM_LEVEL_MIN:
        return "medium"
    return None


def safe_get(d, *keys, default=None):
    """Nested dict getter: safe_get(alert, 'agent', 'name')"""
    cur = d
    for k in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(k, default)
    return cur


def extract_mitre(rule):
    """Pulls MITRE technique IDs and tactics out of the rule block, if present."""
    mitre = rule.get("mitre", {})
    ids = mitre.get("id", []) if isinstance(mitre, dict) else []
    tactics = mitre.get("tactic", []) if isinstance(mitre, dict) else []
    return ids, tactics


def build_supabase_row(alert):
    """
    Transforms a raw Wazuh alert dict into the row shape expected by the
    wazuh_alerts Supabase table (see supabase_schema.sql).
    """
    rule = alert.get("rule", {}) or {}
    level = int(rule.get("level", 0))
    severity = classify_severity(level)

    if severity is None:
        return None  # below threshold, caller should skip

    mitre_ids, mitre_tactics = extract_mitre(rule)

    data_block = alert.get("data", {}) or {}

    row = {
        "alert_id": alert.get("id"),
        "rule_id": rule.get("id"),
        "rule_level": level,
        "severity_label": severity,
        "rule_description": rule.get("description"),
        "rule_groups": rule.get("groups", []),
        "rule_mitre_ids": mitre_ids,
        "rule_mitre_tactics": mitre_tactics,

        "agent_id": safe_get(alert, "agent", "id"),
        "agent_name": safe_get(alert, "agent", "name"),
        "agent_ip": safe_get(alert, "agent", "ip"),

        "manager_name": safe_get(alert, "manager", "name"),
        "location": alert.get("location"),
        "decoder_name": safe_get(alert, "decoder", "name"),

        "full_log": alert.get("full_log"),
        "srcip": data_block.get("srcip"),
        "dstip": data_block.get("dstip"),
        "srcuser": data_block.get("srcuser"),
        "dstuser": data_block.get("dstuser"),

        "raw_alert": alert,
        "alert_timestamp": alert.get("timestamp"),
    }

    # Strip None values for cleanliness (Supabase will use column defaults otherwise)
    return {k: v for k, v in row.items() if v is not None}


# ----------------------------------------------------------------------
# SUPABASE REST CALL
# ----------------------------------------------------------------------

def send_to_supabase(cfg, row):
    url = cfg.get("SUPABASE_URL", "").rstrip("/")
    key = cfg.get("SUPABASE_KEY", "")
    table = cfg.get("SUPABASE_TABLE", "wazuh_alerts")

    if not url or not key:
        logger.error("SUPABASE_URL or SUPABASE_KEY missing from config; aborting send.")
        return False

    endpoint = f"{url}/rest/v1/{table}"
    payload = json.dumps(row).encode("utf-8")

    headers = {
        "Content-Type": "application/json",
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Prefer": "return=minimal",
    }

    req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                status = resp.getcode()
                if 200 <= status < 300:
                    logger.info(
                        "Sent alert_id=%s rule_id=%s severity=%s -> Supabase (HTTP %s)",
                        row.get("alert_id"), row.get("rule_id"), row.get("severity_label"), status,
                    )
                    return True
                logger.warning("Unexpected status %s on attempt %s", status, attempt)
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            logger.error("HTTPError on attempt %s: %s - %s", attempt, e.code, body)
        except urllib.error.URLError as e:
            logger.error("URLError on attempt %s: %s", attempt, e.reason)
        except Exception as e:
            logger.error("Unexpected error on attempt %s: %s", attempt, e)

        if attempt < MAX_RETRIES:
            time.sleep(RETRY_BACKOFF_SECONDS * attempt)

    logger.error("Failed to send alert after %s attempts: alert_id=%s", MAX_RETRIES, row.get("alert_id"))
    return False


# ----------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------

def main():
    if len(sys.argv) < 2:
        logger.error("No alert file path provided by Wazuh. argv=%s", sys.argv)
        sys.exit(1)

    alert_file_path = sys.argv[1]

    try:
        with open(alert_file_path, "r") as f:
            alert = json.load(f)
    except (json.JSONDecodeError, FileNotFoundError, PermissionError) as e:
        logger.error("Failed to read/parse alert file %s: %s", alert_file_path, e)
        sys.exit(1)

    cfg = load_config()

    row = build_supabase_row(alert)
    if row is None:
        # Below medium threshold -- Wazuh's <rule_id>/<level> filter in ossec.conf
        # should normally prevent this script from even being called for low-severity
        # alerts, but we double-check here as a safety net.
        logger.debug("Alert level below threshold, skipping. alert_id=%s", alert.get("id"))
        sys.exit(0)

    success = send_to_supabase(cfg, row)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
