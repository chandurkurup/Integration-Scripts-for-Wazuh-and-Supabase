#!/usr/bin/env python3
"""
test_integration.py
--------------------
Standalone test harness -- run this BEFORE wiring up Wazuh to confirm:
  1. Your Supabase credentials/table are correct
  2. The parsing + severity filtering logic behaves as expected
  3. A test row actually lands in your wazuh_alerts table

Usage:
    python3 test_integration.py /path/to/custom-supabase.conf

If no config path given, defaults to ./custom-supabase.conf
"""

import json
import os
import sys
import tempfile
import importlib.util

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))


def load_main_module():
    spec = importlib.util.spec_from_file_location(
        "custom_supabase", os.path.join(SCRIPT_DIR, "custom-supabase.py")
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


SAMPLE_HIGH_ALERT = {
    "id": "test-high-0001",
    "timestamp": "2026-06-18T12:00:00.000+0000",
    "rule": {
        "id": 5712,
        "level": 12,
        "description": "TEST: Multiple authentication failures followed by a success.",
        "groups": ["authentication_failures"],
        "mitre": {"id": ["T1110"], "tactic": ["Credential Access"]},
    },
    "agent": {"id": "000", "name": "test-agent", "ip": "127.0.0.1"},
    "manager": {"name": "test-manager"},
    "location": "/var/log/test.log",
    "decoder": {"name": "test-decoder"},
    "full_log": "TEST LOG LINE - safe to delete from Supabase",
    "data": {"srcip": "198.51.100.10", "dstuser": "testuser"},
}

SAMPLE_LOW_ALERT = {
    "id": "test-low-0001",
    "timestamp": "2026-06-18T12:00:00.000+0000",
    "rule": {"id": 1, "level": 3, "description": "TEST: low severity, should be skipped"},
}


def main():
    cs = load_main_module()

    config_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(SCRIPT_DIR, "custom-supabase.conf")
    if not os.path.isfile(config_path):
        print(f"[FAIL] Config file not found: {config_path}")
        print("       Copy custom-supabase.conf.example -> custom-supabase.conf and fill in your credentials.")
        sys.exit(1)

    # Temporarily point the module's CONFIG_FILE at the one we were given
    cs.CONFIG_FILE = config_path
    cfg = cs.load_config()

    if not cfg.get("SUPABASE_URL") or "YOUR-PROJECT-REF" in cfg.get("SUPABASE_URL", ""):
        print("[FAIL] SUPABASE_URL not set or still a placeholder. Edit your config file.")
        sys.exit(1)
    if not cfg.get("SUPABASE_KEY") or "YOUR-" in cfg.get("SUPABASE_KEY", ""):
        print("[FAIL] SUPABASE_KEY not set or still a placeholder. Edit your config file.")
        sys.exit(1)

    print("[1/3] Testing severity filtering logic...")
    low_row = cs.build_supabase_row(SAMPLE_LOW_ALERT)
    assert low_row is None, "Low severity alert should be filtered out!"
    print("      OK - low severity alert correctly skipped")

    high_row = cs.build_supabase_row(SAMPLE_HIGH_ALERT)
    assert high_row is not None and high_row["severity_label"] == "high"
    print("      OK - high severity alert correctly classified")

    print("[2/3] Sending test HIGH alert to Supabase...")
    success = cs.send_to_supabase(cfg, high_row)
    if success:
        print("      OK - row inserted. Check your wazuh_alerts table in Supabase (filter alert_id='test-high-0001').")
    else:
        print("      FAIL - see error above / check integrations.log or stderr.")
        sys.exit(1)

    print("[3/3] Simulating a real Wazuh invocation (writes alert to temp file, calls main())...")
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as tmp:
        json.dump(SAMPLE_HIGH_ALERT, tmp)
        tmp_path = tmp.name

    old_argv = sys.argv
    sys.argv = ["custom-supabase.py", tmp_path]
    try:
        cs.main()
    except SystemExit as e:
        if e.code == 0:
            print("      OK - main() executed successfully end-to-end")
        else:
            print(f"      FAIL - main() exited with code {e.code}")
    finally:
        sys.argv = old_argv
        os.unlink(tmp_path)

    print("\nAll tests completed. Remember to delete the test rows (alert_id LIKE 'test-%') from Supabase.")


if __name__ == "__main__":
    main()
